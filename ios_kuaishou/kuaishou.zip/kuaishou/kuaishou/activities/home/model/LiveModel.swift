//
//  LiveModel.swift
//  kuaishou
//
//  Created by 锦锋 on 2017/11/11.
//  Copyright © 2017年 jinfeng. All rights reserved.
//

import UIKit

class LiveModel: NSObject, Codable{

    var code:Int?
    var data:Int?
}
