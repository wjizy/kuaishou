//
//  HomeView.swift
//  kuaishou
//
//  Created by 锦锋 on 2017/10/29.
//  Copyright © 2017年 jinfeng. All rights reserved.
//

import UIKit

class HomeView: UIView {



}
